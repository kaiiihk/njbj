const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Mostra a latência da API, WebSocket e a latência total.'),
    async execute(interaction) {
        const pingEmbed = new EmbedBuilder()
            .setColor('#816AE4')
            .setTitle('🏓 Ping!')
            .setDescription('Pingando...')
            .setTimestamp();

        const msg = await interaction.reply({ embeds: [pingEmbed], fetchReply: true, ephemeral: true });
        const apiLatency = Math.round((msg.createdTimestamp - interaction.createdTimestamp) - interaction.client.ws.ping);
        const latency = msg.createdTimestamp - interaction.createdTimestamp;

        const pongEmbed = new EmbedBuilder()
            .setColor('#816AE4')
            .setTitle('🏓 Pong!')
            .setDescription(`Latência da API: **${apiLatency}ms**\nLatência do WebSocket: **${interaction.client.ws.ping}ms**\nLatência total: **${latency}ms**`)
            .setTimestamp();

        interaction.editReply({ embeds: [pongEmbed], ephemeral: true });
    },
    toJSON() {
        return this.data;
    },
};