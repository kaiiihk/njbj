const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('pago')
        .setDescription('Seta o ticket como pago.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
        .addUserOption(option =>
            option
                .setName('usuário')
                .setDescription('Marque o usuário da compra!')
                .setRequired(true))
        .addAttachmentOption(option =>
            option
                .setName('pagamento')
                .setDescription('Prova do pagamento entregue!')
                .setRequired(true)),
    async execute(interaction, client) {
        const user = interaction.options.getUser('usuário');
        const prova = interaction.options.getAttachment('pagamento');

        // Embed de logs
        let logembed = new EmbedBuilder()
            .setTitle("😍 Produto entregue")
            .setDescription(`Ticket: \`${interaction.channel.name}\`\nID: \`${interaction.channel.id}\`\nPago por: ${interaction.user} \`${interaction.user.id}\`\n\n> Pago: <t:${~~(Date.now() / 1000)}:R>`)
            .setImage(prova.url)
            .setColor("Orange");

        const embed = new EmbedBuilder()
            .setTitle("😍Produto entregue:")
            .setDescription(`Olá! Ah, obrigado por comprar conosco! Seu produto já foi entregue. Esperamos que goste e, se precisar de algo mais, é só nos contatar. Obrigado pela preferência e volte sempre!\n> Ops, e não se esqueca de nós avaliar em <#1107770413922131999>`)
            .setThumbnail("https://cdn-icons-png.flaticon.com/512/2972/2972561.png")
            .setColor("#1e1e1e")

        const embed2 = new EmbedBuilder()
            .setTitle("😍+1 entrega:")
            .setDescription(`${user} Obrigado pela preferência e volte sempre!\n> Ops, e não se esqueca de nós avaliar e postar print do produto recebido em <#1107770413922131999>`)
            .setImage(prova.url)
            .setColor("#1e1e1e")

        // Canal de logs
        const logch = interaction.guild.channels.cache.get("1140069475694157934");
        const entregach = interaction.guild.channels.cache.get("1107770515311034498");
        const refch = interaction.guild.channels.cache.get("1107770413922131999");
        // Envia mensagem no privado do membro
        user.send("Seu produto foi entregue com sucesso! Cheque o seu ticket de compra para mais informações.").then(msg => {
            setTimeout(() => msg.delete(), 1800000)
        }).catch((error) => {
            return
        });
        // Envia embed de produto pago
        interaction.channel.send({ content: `Compre mais vezes com a gente!`, embeds: [embed] })
        // Manda a prova para o canal de entrega
        entregach.send({ embeds: [embed2] })
        // Cria o transcript
        const attachment = await discordTranscripts.createTranscript(interaction.channel, {
            fileName: `${interaction.channel.id}.html`,
        });
        // Manda a log para o canal
        logch.send({ content: `\`💾 - Transcript ⤵\``, embeds: [logembed], files: [attachment] })
        // Adiciona o cargo para o membro
        const member = interaction.guild.members.cache.get(user.id);
        member.roles.add("1137445523654180995").catch((err) => { // IT
            return
        });
        // Marca o usuário no canal de avaliação
        refch.send({ content: `${user}` }).then(msg => {
            setTimeout(() => msg.delete(), 2000)
        }).catch((error) => {
            return
        });
        // Responde a interação
        interaction.reply({
            content: "Ação realizada com sucesso!",
            ephemeral: true
        })
        interaction.channel.delete().catch((err) => {
            interaction.reply({ content: "Erro ao tentar fechar o ticket automaticamente!" })
            return
        })
    },
    toJSON() {
        return this.data;
    },
};