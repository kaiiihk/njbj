const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('valor')
        .setDescription('Calcula o valor dos robux.')
        .addIntegerOption(option =>
            option.setName('robux')
            .setDescription('Insira a quantidade de Robux.')
            .setRequired(true)
        ),
    async execute(interaction) {
        const robux = interaction.options.getInteger('robux');
        const valorSemTaxa = robux * 0.0300; // Valor sem taxa
        const valorComTaxa = valorSemTaxa * 1.429; // Valor com taxa
        const taxa = robux - robux * 0.30; // Valor da taxa
        const embed = new EmbedBuilder()
            .setAuthor({ name: `Conversão de robux:` })
            .setDescription(`**💵 Valor sem taxa: \`R$ ${valorSemTaxa.toFixed(2)}\`**
            **💵 Valor com taxa: \`R$ ${valorComTaxa.toFixed(2)}\`**
            
            > **Quantidade obtida sem taxa: \`${taxa.toFixed(0)}\`**
            > **Quantidade obtida com taxa: \`${robux.toFixed(0)}\`**
            `)
            .setColor("White")

        await interaction.reply({ embeds: [embed]});
    },
    toJSON() {
        return this.data;
    },
};