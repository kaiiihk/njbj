const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('aprovado')
        .setDescription('Seta o ticket como aprovado.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
        .addUserOption(option =>
            option
                .setName('usuário')
                .setDescription('Marque o usuário da compra!')
                .setRequired(true)),
    async execute(interaction, client) {
        const user = interaction.options.getUser('usuário');

        // Nome do canal com: data, dia, nome, id.
        const channelName = `✅・👤${user.username}・🆔${user.id}`;

        // Embed de confirmamento de aprovação
        const embed = new EmbedBuilder()
            .setTitle("✅Pagamento aprovado:")
            .setDescription(`Oba, obrigado por comprar conosco! basta aguardar sua entrega\n> Lembrando que o prazo de entrega é em até 48 horas!\n\nEnquanto isto você pode ir enviando seu nickname no roblox(sem ser display name), ou o link de sua gamepass! depende do produto que foi comprado. Se foi **gamepass** mande a primeira opção, se foi **robux** mande a segunda opção.`)
            .setThumbnail("https://cdn-icons-png.flaticon.com/512/7518/7518748.png")
            .setColor("#1e1e1e")

        // Embed de logs
        let logembed = new EmbedBuilder()
            .setTitle("💳 Pagamento aprovado")
            .setDescription(`Ticket: \`${interaction.channel.name}\`\nID: \`${interaction.channel.id}\`\nConfirmado por: ${interaction.user} \`${interaction.user.id}\`\n\n> Confirmado: <t:${~~(Date.now() / 1000)}:R>`)
            .setColor("Blue");

        // Canal de logs
        const logchannel = interaction.guild.channels.cache.get("1140069475694157934");
        // Envia embed de pagamento aprovado
        interaction.channel.send({ content: `Parabéns :)`, embeds: [embed] })
        // Troca o emoji do nome do canal
        interaction.channel.setName(channelName)
        // Manda a log para o canal
        logchannel.send({ embeds: [logembed] })
        // Responde a interação
        interaction.reply({
            content: "Ação realizada com sucesso!",
            ephemeral: true
        })
    },
    toJSON() {
        return this.data;
    },
};