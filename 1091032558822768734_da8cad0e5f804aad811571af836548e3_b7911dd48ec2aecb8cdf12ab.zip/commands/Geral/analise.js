const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('analise')
        .setDescription('Seta o ticket como análise')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageThreads)
        .addUserOption(option =>
            option
                .setName('usuário')
                .setDescription('Marque o usuário da compra!')
                .setRequired(true)),
    async execute(interaction, client) {
        const user = interaction.options.getUser('usuário');

        // Nome do canal com: data, dia, nome, id.
        const channelName = `⌛・👤${user.username}・🆔${user.id}`;

        // Embed de confirmamento de aprovação
        const embed = new EmbedBuilder()
            .setTitle("⚠️Em análise:")
            .setDescription(`Oba, obrigado por comprar conosco! basta aguardar confirmarmos seu pagamento, logo faremos a entrega.`)
            .setThumbnail("https://cdn-icons-png.flaticon.com/512/4388/4388167.png")
            .setColor("#1e1e1e")

        // Embed de logs
        let logembed = new EmbedBuilder()
            .setTitle("⚠️ Em análise")
            .setDescription(`Ticket: \`${interaction.channel.name}\`\nID: \`${interaction.channel.id}\`\nSetado em análise por: ${interaction.user} \`${interaction.user.id}\`\n\n> Confirmado: <t:${~~(Date.now() / 1000)}:R>`)
            .setColor("Yellow");

        // Canal de logs
        const logchannel = interaction.guild.channels.cache.get("1140069475694157934");
        // Envia embed de pagamento aprovado
        interaction.channel.send({ content: `Aguardando...`, embeds: [embed] })
        // Troca o emoji do nome do canal
        interaction.channel.setName(channelName)
        // Manda a log para o canal
        logchannel.send({ embeds: [logembed] })
        // Responde a interação
        interaction.reply({
            content: "Ação realizada com sucesso!",
            ephemeral: true
        })
    },
    toJSON() {
        return this.data;
    },
};