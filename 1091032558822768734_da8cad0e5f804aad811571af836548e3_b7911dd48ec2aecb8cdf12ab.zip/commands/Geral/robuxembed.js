const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticketembed')
        .setDescription('Mostra a embed de compra robux.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction, client) {
        const embed = new EmbedBuilder()
            .setAuthor({ name: `Ticket system | ${interaction.guild.name}`, iconURL: "https://cdn.discordapp.com/attachments/1107780433908867183/1148775297760632983/aaaaaaaaaaa.png" })
            .setDescription("<:8263blurplemembers:1148080776957673502> Olá <@&1107747267722620968>, Abaixo está algumas informaçôes de nosso hórario de atendimento e botão de compra.\n\n<a:1033233894004244572:1148291981815074897>  **Horário de atendimento:**\n> **Segunda a sexta.**\n> ```12:00 as 20:00```\n> **Sáb., Dom., e Feriados.**\n> ```13:00 as 19:00```\n\n<a:1015437976781725766:1143310896236593233>  **Importante:**\n> Clique no botão abaixo para abrir um ticket de compra! Tickets aberto sem motivo não serão tolerados, e é passivo de punição.")
            .setColor("#1e1e1e")

        let button = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("buyrobux")
                .setLabel("Comprar")
                .setEmoji('<:Caixa:1107260043256143923>')
                .setStyle("Success"),
            new ButtonBuilder()
                .setCustomId("termos")
                .setLabel("Termos")
                .setEmoji('<:1100582396744716318:1125945486378016831>')
                .setStyle("Secondary"),
            new ButtonBuilder()
                .setCustomId("faq")
                .setLabel("Faq")
                .setEmoji('<:emoji_58:1102465739010613308>')
                .setStyle("Secondary"),
        );

        await interaction.channel.send({ embeds: [embed], components: [button] });
        await interaction.reply({ content: "Comando executado com sucesso!", ephemeral: true });
    },
    toJSON() {
        return this.data;
    },
};